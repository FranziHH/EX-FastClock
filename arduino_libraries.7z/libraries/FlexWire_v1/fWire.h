#ifndef fWire_h
#define fWire_h

#include <FlexWire_v1.h>

extern FlexWire flexWire;

// typedef FlexWire TwoWire;

#endif 
